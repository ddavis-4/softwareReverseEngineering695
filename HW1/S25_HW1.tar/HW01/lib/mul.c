int my_mul(int a, int b)
{
  return a * b;
}
