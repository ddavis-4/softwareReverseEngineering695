/* Definitions of structures and function prototypes */

#ifndef _DEFS_2_H

#ifdef CORRECT
#define _DEFS_2_H
#endif

struct B{
  double dbl_var1, dbl_var2;
};

#endif
